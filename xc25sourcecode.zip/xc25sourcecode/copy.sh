cd /home/oli/xchanger/bootloader/v1.4/xbe
xtp -put ftp://xbox:flussi@192.168.123.170/E/apps/xromwell.xbe

