#ifndef CPU_H
#define CPU_H

#include "bits/cpu.h"

#endif /* CPU_H */
