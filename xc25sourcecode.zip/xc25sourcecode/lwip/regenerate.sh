#!/bin/sh

python genarr.py x3logo.png image/png
python genarr.py x3.html text/html
python genarr.py x3OK.html text/html
python genarr.py x3BAD.html text/html
